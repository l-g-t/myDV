document.addEventListener('DOMContentLoaded', () => {
  const ipInput = document.getElementById('tv-ip');
  const pushBtn = document.getElementById('push-btn');
  const statusDiv = document.getElementById('status');

  const scanBtn = document.getElementById('scan-btn');
  const datalist = document.getElementById('device-list');

  // Load the last saved IP from storage
  chrome.storage.local.get(['tvIp'], (result) => {
    if (result.tvIp) {
      ipInput.value = result.tvIp;
    }
  });

  scanBtn.addEventListener('click', async () => {
    let currentIp = ipInput.value.trim();
    let subnet = '192.168.1'; // default
    if (currentIp) {
      const parts = currentIp.replace(/^https?:\/\//, '').split(':')[0].split('.');
      if (parts.length === 4) {
        subnet = parts.slice(0, 3).join('.');
      }
    }
    
    // Show custom modal to get subnet
    const modal = document.getElementById('subnet-modal');
    const subnetInput = document.getElementById('subnet-input');
    const cancelBtn = document.getElementById('modal-cancel');
    const confirmBtn = document.getElementById('modal-confirm');
    
    subnetInput.value = subnet;
    modal.classList.add('show');
    subnetInput.focus();

    const userSubnet = await new Promise((resolve) => {
      const handleConfirm = () => {
        cleanup();
        resolve(subnetInput.value.trim());
      };
      const handleCancel = () => {
        cleanup();
        resolve(null);
      };
      const handleKey = (e) => {
        if (e.key === 'Enter') handleConfirm();
        if (e.key === 'Escape') handleCancel();
      };
      
      const cleanup = () => {
        modal.classList.remove('show');
        confirmBtn.removeEventListener('click', handleConfirm);
        cancelBtn.removeEventListener('click', handleCancel);
        subnetInput.removeEventListener('keydown', handleKey);
      };

      confirmBtn.addEventListener('click', handleConfirm);
      cancelBtn.addEventListener('click', handleCancel);
      subnetInput.addEventListener('keydown', handleKey);
    });

    if (!userSubnet) return;
    subnet = userSubnet;

    showStatus(`正在扫描网段 ${subnet}.x，请稍候...`, 'info');
    scanBtn.disabled = true;
    const svgIcon = scanBtn.querySelector('svg');
    if (svgIcon) svgIcon.classList.add('spinning');
    
    datalist.innerHTML = '';
    let foundCount = 0;
    
    // Scan all 255 IPs in parallel with short timeout
    const promises = [];
    for (let i = 1; i <= 254; i++) {
      const target = `${subnet}.${i}`;
      promises.push(
        fetch(`http://${target}:9978/api/info`, { signal: AbortSignal.timeout(1500) })
          .then(res => res.json())
          .then(data => {
            if (data && data.success && data.app_name === 'myDV') {
              const option = document.createElement('option');
              const label = data.device_name || target;
              option.value = target;
              option.textContent = `${label} (${target})`;
              datalist.appendChild(option);
              
              if (foundCount === 0) {
                ipInput.value = target; // auto-fill first found
              }
              foundCount++;
            }
          })
          .catch(() => {}) // ignore errors/timeouts
      );
    }
    
    await Promise.allSettled(promises);
    
    scanBtn.disabled = false;
    if (svgIcon) svgIcon.classList.remove('spinning');
    
    if (foundCount > 0) {
      showStatus(`扫描完成，发现 ${foundCount} 台电视设备，已自动选择！你也可以在下拉框中选择。`, 'success');
    } else {
      showStatus(`扫描完成，未发现设备。请确认电视是否开机运行了 myDV，且网段是 ${subnet}。`, 'error');
    }
  });

  pushBtn.addEventListener('click', async () => {
    const ip = ipInput.value.trim();
    if (!ip) {
      showStatus('请输入电视 IP 地址', 'error');
      return;
    }

    // Save the IP for next time
    chrome.storage.local.set({ tvIp: ip });

    // Check if current tab is douyin.com
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab.url.includes('douyin.com')) {
      showStatus('错误：请在抖音网页版 (douyin.com) 使用此插件', 'error');
      return;
    }

    showStatus('正在提取完整凭证...', '');
    pushBtn.disabled = true;

    try {
      // 1. Get all cookies for douyin.com (including HttpOnly like sessionid)
      const cookies = await new Promise((resolve) => {
        chrome.cookies.getAll({ domain: ".douyin.com" }, resolve);
      });
      
      const cookieStr = cookies.map(c => `${c.name}=${c.value}`).join('; ');
      
      if (!cookieStr || !cookieStr.includes('sessionid')) {
        showStatus('未找到有效的登录 Cookie(sessionid)，请确保您已登录抖音网页版。', 'error');
        pushBtn.disabled = false;
        return;
      }

      // 2. Inject script to extract localStorage security tokens
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: extractLocalStorageTokens
      }, async (results) => {
        if (chrome.runtime.lastError || !results || !results[0]) {
          showStatus('执行内容脚本失败: ' + (chrome.runtime.lastError?.message || '未知错误'), 'error');
          pushBtn.disabled = false;
          return;
        }

        const data = results[0].result;
        if (data.error) {
          showStatus('票据提取失败: ' + data.error, 'error');
          pushBtn.disabled = false;
          return;
        }

        // 3. Assemble payload
        const payload = {
          cookie: cookieStr,
          security_payload: data.security,
          private_key: data.privateKey
        };

        showStatus(`提取成功！正在推送至 ${ip}:9978 ...`, '');

        // 4. Send to TV
        try {
          // Normalize IP format (in case user entered http:// or port)
          let targetIp = ip.replace(/^https?:\/\//, '').split(':')[0];
          
          const response = await fetch(`http://${targetIp}:9978/api/submit`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
          });

          const resData = await response.json();
          if (resData.success) {
            showStatus('推送成功！电视端应用应已生效。', 'success');
          } else {
            showStatus('电视端返回错误: ' + (resData.message || '未知错误'), 'error');
          }
        } catch (err) {
          showStatus(`网络请求失败。请检查：1. 电视 IP 是否准确 2. myDV 应用是否在前台运行 3. 电脑与电视是否在同一局域网`, 'error');
        } finally {
          pushBtn.disabled = false;
        }
      });
    } catch (e) {
      showStatus('提取过程发生异常: ' + e.message, 'error');
      pushBtn.disabled = false;
    }
  });

  function showStatus(msg, className) {
    statusDiv.textContent = msg;
    statusDiv.className = className ? `show ${className}` : '';
  }
});

// This function executes in the context of the douyin.com page
function extractLocalStorageTokens() {
  try {
    const result = {
      security: '',
      privateKey: '',
      error: null
    };

    let foundSecurity = false;
    let foundCrypto = false;

    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      
      // Extract ticket and ts_sign
      if (k && k.includes('s_sdk_sign_data_key/web_protect')) {
        try {
          const v = localStorage.getItem(k);
          const d = JSON.parse(v);
          const inner = typeof d.data === 'string' ? JSON.parse(d.data) : d;
          if (inner.ticket || inner.ts_sign) {
            result.security = JSON.stringify({
              ticket: inner.ticket || '',
              ts_sign: inner.ts_sign || '',
              client_cert: inner.client_cert || ''
            });
            foundSecurity = true;
          }
        } catch (e) {}
      }
      
      // Extract ec_privateKey
      if (k && k.includes('s_sdk_crypt_sdk')) {
        try {
          const v2 = localStorage.getItem(k);
          const d2 = JSON.parse(v2);
          const inner2 = typeof d2.data === 'string' ? JSON.parse(d2.data) : d2;
          if (inner2.ec_privateKey) {
            result.privateKey = inner2.ec_privateKey;
            foundCrypto = true;
          }
        } catch (e2) {}
      }
    }

    if (!foundSecurity || !foundCrypto) {
      result.error = '未在当前页面找到风控票据。请确保您已在网页端登录抖音，并尝试刷新页面重试。';
    }

    return result;
  } catch (err) {
    return { error: err.message };
  }
}
